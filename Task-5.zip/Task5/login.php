<?php
	
		if(isset($_POST["name"]))
		{
			if($_POST["name"]=="")
			{
				echo "enter username!";
			}
			elseif(strlen($_POST["name"])<2)
			{
				echo "username must contain atleast 2 characters!";
			}
			elseif(!(preg_match("/^[a-zA-Z.-]*$/",$_POST["name"])))
			{
				echo "username should contain alphanumeric . - _";
			}
		}
		if(isset($_POST["password"]))
		{	
			if($_POST["password"]=="")
			{
				echo "enter password!";
			}
			elseif(strlen($_POST["password"])<8)
			{
				echo "pass must contain min 8 characters!";
			}
			elseif(!(preg_match("/^[a-zA-Z0-9@#$%]*$/",($_POST["password"]))))
			{
				echo "password must contain @,#,$ or %";
			}
	    }
?>
<fieldset>
    <legend><b>LOGIN</b></legend>
    <form action="#" method = "POST">
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text" name = "name"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password" name = "password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" name = "submit" value="Submit">        
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>