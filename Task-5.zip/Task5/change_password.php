<?php
		
	if(isset($_POST['pass']) && isset($_POST['newpass']) && isset($_POST['repass']))
	{
		if(($_POST['pass']) == ($_POST['newpass']))
		{
			echo "new password is same as current password!";
		}
		elseif(($_POST['newpass']) != ($_POST['repass']))
		{
			echo "new password and retype password dont match!";
		}
		else
		{
			echo "password changed!";
		}
	}
	
?>
<fieldset>
    <legend><b>CHANGE PASSWORD</b></legend>
    <form action = "#" method = "POST">
        <table>
            <tr>
                <td><font size="3">Current Password</font></td>
				<td>:</td>
                <td><input type="password" name = "pass"/></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="green">New Password</font></td>
				<td>:</td>
                <td><input type="password" name = "newpass"/></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="red">Retype New Password</font></td>
				<td>:</td>
                <td><input type="password" name = "repass"/></td>
                <td></td>
            </tr>
        </table>
        <hr />
        <input type="submit" value="Submit" />
    </form>
</fieldset>