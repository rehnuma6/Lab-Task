<?php
	
	if(isset($_POST['dd'])){
		echo $_POST['dd'];
		echo "/";
	}
	
	if(isset($_POST['mm'])){
		echo $_POST['mm'];
		echo "/";
	}
	
	if(isset($_POST['yyyy'])){
		echo $_POST['yyyy'];
	}
?>