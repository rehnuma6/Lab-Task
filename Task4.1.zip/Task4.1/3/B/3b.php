<?php
	
	if(isset($_POST['dd'])){
		echo $_POST['dd'];
		echo "/";
	}
	
	if(isset($_POST['mm'])){
		echo $_POST['mm'];
		echo "/";
	}
	
	if(isset($_POST['yyyy'])){
		echo $_POST['yyyy'];
	}
?>
<form action="#" method="POST">
	<fieldset>
		<legend>DATE OF BIRTH</legend>
		dd
		<select name ="dd">/
			<option value = "1">1</option>
			<option value = "1">2</option>
		</select>
		mm
		<select name ="mm">/
			<option value = "12">12</option>
			<option value = "10">10</option>
		</select>
		yyyy
		<select name ="yyyy">/
			<option value = "2018">2018</option>
			<option value = "2017">2017</option>
		</select>
		
		<br></br>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>