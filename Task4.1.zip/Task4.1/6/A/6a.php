<?php

	if(isset($_POST['group']))
	{ echo $_POST['group'];}

?>