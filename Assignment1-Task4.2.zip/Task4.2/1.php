<?php
	if(isset($_POST['name']))
	{
		if($_POST['name']=='')
			
			{
				echo "cannot be empty!";
			}
			
		elseif(str_word_count($_POST['name'])<2)

			{
				echo "must contain 2 words!";
			}
		
		elseif(!(preg_match("/^[a-zA-Z.-]*$/",($_POST['name']))))
			{
				echo ($_POST['name']);
			}
			
		elseif((ord($_POST['name'])<65)|| (ord($_POST['name'])>90) && (ord($_POST['name'])<97)||(ord($_POST['name'])>122))
			{
				echo "name should start with a letter!";
			}
		
		else 
		{
				echo ($_POST['name']);
		}			
	}
?>

<form action="#" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<input type="text" name="name" value="" ><br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>