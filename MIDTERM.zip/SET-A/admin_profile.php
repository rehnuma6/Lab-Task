<center>
	<table border="1" cellpadding="5" cellspacing="0">
	
		<tr>
			<td colspan="2" align="CENTER">Profile</td>
		</tr>
		
		<tr>
			<td>ID</td>
			<td><?php session_start();
				echo $_SESSION['id'];?>
		</tr>
		
		<tr>
			<td>NAME</td>
			<td><?php
				echo $_SESSION['name'];?></td>
		</tr>	
		
		<tr>
			<td>USER TYPE</td>
			<td><?php
				echo $_SESSION['type'];?></td>
		</tr>
		
		<tr>
			<td colspan="2" align="right"><a href="admin_home.php">Go Home</a></td>
		</tr>
	</table>			
</center>