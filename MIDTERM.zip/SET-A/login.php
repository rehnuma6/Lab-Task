<?php
	if(isset($_POST['login']))
	{
		if(!empty($_POST['id'])&& !empty($_POST['password']))
		{
			$id=$_POST['id'];
			$pass=$_POST['password'];
			
			$c=mysqli_connect('localhost','root','','webtec');
			$sql="SELECT id,password,name,type FROM user WHERE id='$id' AND password='$pass'";
			
			$result=mysqli_query($c,$sql);
			
			while($row=mysqli_fetch_array($result))
			{
				$db_id=$row['id'];
				$db_pass=$row['password'];
				$db_uname=$row['name'];
				$db_utype=$row['type'];
				
				if($id==$db_id && $pass==$db_pass)
				{
					session_start();
					$_SESSION['id']=$db_id;
					$_SESSION['type']=$db_utype;
					$_SESSION['name']=$db_uname;
					
					if($_SESSION['type']=='admin')
					{
						header("Location:admin_home.php");
					}
					else 
					{
						header("Location:user_home.php");
					}
				}
				else
				{
					header("Location:login.php");
				}
				
			}
			mysqli_close($c);
		}
		else
		{
			echo "id/password cant be empty!";
		}
		
	}
?>

<center>
<form action="#" method="POST">
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input type="text" name="id"><br/>                               
					Password<br/>
					<input type="password" name="password">
					<br /><hr/>
					<input type="submit" value="login" name="login">
					<a href="registration.php">Register</a>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>