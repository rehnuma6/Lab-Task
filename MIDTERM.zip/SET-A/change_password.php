<?php
	if(isset($_POST['submit']))
	{
		if($_POST['pass']== '')
		{
			echo "enter old password!";
		}
		elseif($_POST['newpass']=='')
		{
			echo "enter new password!";
		}
		elseif($_POST['repass']=='')
		{
			echo "retype password!";
		}
		elseif($_POST['newpass']!==$_POST['repass'])
		{
			echo "new password does not match retyped password";
		}
		elseif($_POST['pass']==$_POST['newpass'])
		{
			echo "old password cant match new password!";
		}
		else
		{
			$oldpass = $_POST['pass'];
			$newpass = $_POST['newpass'];
			$repass = $_POST['repass'];
		
			$con = mysqli_connect('localhost','root','','webtec');
			$sql = "UPDATE user SET password='$newpass' WHERE password='$oldpass'";
			$result = mysqli_query($con,$sql);
		
			echo "password changed!";
			mysqli_close();
			
		}
		
	}
?>
<center>
	<form action = "#" method = "POST">
		<table border="0" cellspacing="0" cellpadding="5">
			<tr>
				<td>
					<fieldset>
						<legend>CHANGE PASSWORD</legend>
						Current Password<br />
						<input type="password" name = "pass" /><br />
						New Password<br />
						<input type="password" name = "newpass"/><br />
						Retype New Password<br />
						<input type="password" name = "repass" />								
						<hr />
						<input type="submit" name = "submit" value="change" />     
						<a href="user_home.php">Home</a>						
					</fieldset>
				</td>
			</tr>
		</table>
	</form>
</center>